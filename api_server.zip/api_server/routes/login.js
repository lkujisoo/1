const router = require('koa-router')()
//引入MySQL数据库
const query = require('./MYSQL');
router.prefix('/login');

router.get('/', function(ctx, next) {
	ctx.body = '这是登录页面'
});

//登录页面，查询数据库是否有该用户并返回前端请求的数据
router.post('/', async (ctx, next) => {
	console.log(ctx.request.body);
	let name = ctx.request.body.name;
	let pass = ctx.request.body.password;
	//根据用户名和密码查询数据库
	let a = await query(`SELECT * FROM user where uname = '${name}' and pass = '${pass}'`);
	// console.log(a);
	// console.log(a.length);
	// 格式化数据类型
	var dataString = JSON.stringify(a);
	var result = JSON.parse(dataString);
	console.log(result);
	
	var data;
	if (result.length > 0) {
		// 得到用户的角色  0:超级管理员  2: 住户
		var roler = result[0].roler;
		console.log(roler);
		// 定义 超级管理员 的权限列表
		var routerlist0 = [
			// {
			// 	id: 1,
			// 	authName: "个人中心",
			// 	path: "grzx",
			// 	children: [{
			// 		id: "1.1",
			// 		authName: "个人信息",
			// 		path: "xgmm",
			// 		children: []
			// 	}]
			// },
			{
				id: 2,
				authName: "社区信息管理",
				path: "lygl",
				children: [{
					id: "2.1",
					authName: "社区公告管理",
					path: "newly",
					children: []
				}]
			},
			{
				id: 3,
				authName: "楼栋管理",
				path: "ssgl",
				children: [{
						id: "3.1",
						authName: "楼栋列表",
						path: "sslb",
						children: []
					}]
			},
			{
				id: 4,
				authName: "活动管理",
				path: "yhqxgl",
				children: [{
						id: "4.1",
						authName: "活动列表",
						path: "yhlb",
						children: []
					}
				]
			},
			{
				id: 5,
				authName: "居民管理",
				path: "xsgl",
				children: [{
					id: "5.1",
					authName: "居民列表",
					path: "xslb",
					children: []
				}]
			},
			
		]
		
		// 定义 学生 权限路由表
		var routerlist2 = [
			{
				id: 1,
				authName: "个人中心",
				path: "gr",
				children: [{
					id: "1.1",
					authName: "个人信息",
					path: "grxx",
					children: []
				}]
			},
			
			{
				id: 9,
				authName: "社区信息",
				path: "grzx",
				children: [{
					id: "1.1",
					authName: "社区基本信息",
					path: "xgmm"
				},{
					id:"1.2",
					authName:"社区公告信息",
					path:"gg"
				}
				]
			},
		
			{
				id: 6,
				authName: "社区活动",
				path: "hqfw",
				children: [{
						id: "6.1",
						authName: "活动报名",
						path: "shbx",
						children: []
					},
					{
						id: "6.2",
						authName: "报名详情",
						path: "bxlb",
						children: []
					}
				]
			},
			{
				id: 7,
				authName: "生活服务",
				path: "shfw",
				children: [{
						id: "7.1",
						authName: "电费充值",
						path: "jdf"
					},
					{
						id: "7.2",
						authName: "水费充值",
						path: "xyw"
					},
					{
						id: "7.3",
						authName: "天然气",
						path: "xyykt"
					}
				]
			},
		]
		if(roler == 0){
			// 超级管理员
			data = {
				code: 200,
				data: result,
				route: routerlist0
			};
		}
		else{
			// 住户
			data = {
				code: 200,
				data: result,
				route: routerlist2
			};
		}
		
		ctx.body = data;
	} else {
		let data = {
			code: 0
		};
		ctx.body = data;
	}
});
// 修改用户信息
router.post('/update', async (ctx, next) => {
	console.log(ctx.request.body);
	let id = ctx.request.body.id;
	let pass = ctx.request.body.pass;
	let xueyuan = ctx.request.body.xueyuan;
	let banji = ctx.request.body.banji;
	let tel = ctx.request.body.tel;
	let lynumber = ctx.request.body.lynumber;
	let menpaihao = ctx.request.body.menpaihao;
	//根据用户id值更新数据
	let a = await query(
		`update user set pass = '${pass}',tel = '${tel}',lynumber = '${lynumber}',menpaihao = '${menpaihao}' where id = ${id}`
	);
	console.log(a);

	if (a.changedRows == 1) {
		// 更新成功
		//根据id查询数据库,返回前端
		let newA = await query(`SELECT * FROM user WHERE id = ${id}`);
		// 格式化数据类型
		var newDataString = JSON.stringify(newA);
		var newResult = JSON.parse(newDataString);
		console.log(newResult);
		// 200代表更新成功
		let data = {
			code: 200,
			newResult
		};
		ctx.body = data;
	} else {
		let data = {
			code: 0
		};
		ctx.body = data;
	}
});



module.exports = router
