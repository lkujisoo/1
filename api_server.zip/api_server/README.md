# api_server

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run start